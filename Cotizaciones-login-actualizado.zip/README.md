# DACATECH Cotizaciones — Android

App de cotizaciones de DACATECH (WebView local). Application ID: `com.dacatech.cotizaciones`. Versión 1.0.
Datos de empresa, logo y formatos editables dentro de la app (pestaña "Mi empresa").
